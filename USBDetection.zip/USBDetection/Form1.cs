﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LibUsbDotNet.DeviceNotify;
using LibUsbDotNet;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace USBDetection
{
    public partial class Form1 : Form
    {
        IDeviceNotifier deviceN = DeviceNotifier.OpenDeviceNotifier();
        List<BoundScript> allScripts = new List<BoundScript>();
        XmlSerializer xmlS = new XmlSerializer(typeof(List<BoundScript>), new Type[]{typeof(BoundScript)});

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(File.Exists("Scripts.xml"))
            {
                FileStream f = null;
                try
                {
                    f = File.Open("Scripts.xml", FileMode.Open);
                    allScripts = (List<BoundScript>)xmlS.Deserialize(f);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    if(f!=null)
                        f.Close();
                }
            }
            deviceN.OnDeviceNotify+=new EventHandler<DeviceNotifyEventArgs>(deviceN_OnDeviceNotify);
        }
        private void deviceN_OnDeviceNotify(object sender, DeviceNotifyEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate
                {
                    deviceN_OnDeviceNotify(sender, e);
                });
            }
            if (!lb_USBDevices.Items.Contains(e.Device.ClassGuid))
            {
                lb_USBDevices.Items.Add(e.Device.ClassGuid);
            }
            if (cb_ProcessEvents.Checked)
            {
                foreach (BoundScript b in allScripts)
                {
                    if (b.usbUniqueID == e.Device.ClassGuid.ToString())
                    {
                        if (e.EventType == EventType.DeviceArrival)
                        {
                            try
                            {
                                b.RunInsertScript();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                        }

                        if (e.EventType == EventType.DeviceRemoveComplete)
                        {
                            try
                            {
                                b.RunRemoveScript();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (lb_USBDevices.SelectedIndices.Count < 1)
                return;
            BoundScript bound = new BoundScript();
            bound.usbUniqueID = lb_USBDevices.SelectedItem.ToString();
            bound.OnInsertPath = txt_InsertPath.Text;
            bound.OnInsertArgs = txt_InsertArgs.Text;
            bound.OnRemovePath = txt_RemovePath.Text;
            bound.OnRemoveArgs = txt_RemoveArgs.Text;
            for(int i=0;i<allScripts.Count;i++)
            {
                if (allScripts[i].usbUniqueID == bound.usbUniqueID)
                {
                    allScripts.RemoveAt(i);
                }
            }
            allScripts.Add(bound);
            TextWriter f = null;
            try
            {
                f = new StreamWriter("Scripts.xml", false);
                xmlS.Serialize(f, allScripts);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (f != null)
                    f.Close();
            }
        }

        private void btn_RemoveBrowse_Click(object sender, EventArgs e)
        {
            ofd_Remove.ShowDialog();
        }

        private void ofd_Insert_FileOk(object sender, CancelEventArgs e)
        {
            txt_InsertPath.Text = ofd_Insert.FileNames[0];
        }

        private void ofd_Remove_FileOk(object sender, CancelEventArgs e)
        {
            txt_RemovePath.Text = ofd_Remove.FileNames[0];
        }

        private void btn_InsertBrowse_Click(object sender, EventArgs e)
        {
            ofd_Insert.ShowDialog();
        }

        private void lb_USBDevices_MouseClick(object sender, MouseEventArgs e)
        {
            if (lb_USBDevices.SelectedIndices.Count > 0)
            {
                string temp = lb_USBDevices.SelectedItem.ToString();
                foreach (BoundScript b in allScripts)
                {
                    if (temp == b.usbUniqueID)
                    {
                        txt_InsertArgs.Text = b.OnInsertArgs;
                        txt_InsertPath.Text = b.OnInsertPath;
                        txt_RemoveArgs.Text = b.OnRemoveArgs;
                        txt_RemovePath.Text = b.OnRemovePath;
                    }
                }
            }
        }
    }
}
