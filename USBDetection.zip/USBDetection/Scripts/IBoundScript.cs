﻿using System;
namespace USBDetection
{
    interface IBoundScript
    {
        void RunInsertScript();
        void RunRemoveScript();
    }
}
