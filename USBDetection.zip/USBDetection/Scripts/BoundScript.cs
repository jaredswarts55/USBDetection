﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace USBDetection
{
    public class BoundScript : USBDetection.IBoundScript
    {
        public string usbUniqueID;
        public string OnInsertPath;
        public string OnInsertArgs;
        public string OnRemovePath;
        public string OnRemoveArgs;
        public BoundScript()
        { }
        public void RunInsertScript()
        {
            Process.Start(OnInsertPath, OnInsertArgs);
        }
        public void RunRemoveScript()
        {
            Process.Start(OnRemovePath, OnRemoveArgs);
        }
    }
}
