﻿namespace USBDetection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_USBDevices = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_InsertPath = new System.Windows.Forms.TextBox();
            this.txt_RemovePath = new System.Windows.Forms.TextBox();
            this.btn_InsertBrowse = new System.Windows.Forms.Button();
            this.btn_RemoveBrowse = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.txt_InsertArgs = new System.Windows.Forms.TextBox();
            this.txt_RemoveArgs = new System.Windows.Forms.TextBox();
            this.ofd_Insert = new System.Windows.Forms.OpenFileDialog();
            this.ofd_Remove = new System.Windows.Forms.OpenFileDialog();
            this.cb_ProcessEvents = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lb_USBDevices
            // 
            this.lb_USBDevices.FormattingEnabled = true;
            this.lb_USBDevices.Location = new System.Drawing.Point(12, 25);
            this.lb_USBDevices.Name = "lb_USBDevices";
            this.lb_USBDevices.Size = new System.Drawing.Size(337, 95);
            this.lb_USBDevices.TabIndex = 0;
            this.lb_USBDevices.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lb_USBDevices_MouseClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Un-plug or Plug-in a device to list it";
            // 
            // txt_InsertPath
            // 
            this.txt_InsertPath.Location = new System.Drawing.Point(12, 171);
            this.txt_InsertPath.Name = "txt_InsertPath";
            this.txt_InsertPath.Size = new System.Drawing.Size(256, 20);
            this.txt_InsertPath.TabIndex = 2;
            // 
            // txt_RemovePath
            // 
            this.txt_RemovePath.Location = new System.Drawing.Point(12, 312);
            this.txt_RemovePath.Name = "txt_RemovePath";
            this.txt_RemovePath.Size = new System.Drawing.Size(256, 20);
            this.txt_RemovePath.TabIndex = 3;
            // 
            // btn_InsertBrowse
            // 
            this.btn_InsertBrowse.Location = new System.Drawing.Point(274, 171);
            this.btn_InsertBrowse.Name = "btn_InsertBrowse";
            this.btn_InsertBrowse.Size = new System.Drawing.Size(75, 20);
            this.btn_InsertBrowse.TabIndex = 4;
            this.btn_InsertBrowse.Text = "Browse";
            this.btn_InsertBrowse.UseVisualStyleBackColor = true;
            this.btn_InsertBrowse.Click += new System.EventHandler(this.btn_InsertBrowse_Click);
            // 
            // btn_RemoveBrowse
            // 
            this.btn_RemoveBrowse.Location = new System.Drawing.Point(274, 311);
            this.btn_RemoveBrowse.Name = "btn_RemoveBrowse";
            this.btn_RemoveBrowse.Size = new System.Drawing.Size(75, 20);
            this.btn_RemoveBrowse.TabIndex = 5;
            this.btn_RemoveBrowse.Text = "Browse";
            this.btn_RemoveBrowse.UseVisualStyleBackColor = true;
            this.btn_RemoveBrowse.Click += new System.EventHandler(this.btn_RemoveBrowse_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(274, 417);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_Save.TabIndex = 6;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.button3_Click);
            // 
            // txt_InsertArgs
            // 
            this.txt_InsertArgs.Location = new System.Drawing.Point(40, 208);
            this.txt_InsertArgs.Name = "txt_InsertArgs";
            this.txt_InsertArgs.Size = new System.Drawing.Size(256, 20);
            this.txt_InsertArgs.TabIndex = 7;
            // 
            // txt_RemoveArgs
            // 
            this.txt_RemoveArgs.Location = new System.Drawing.Point(40, 338);
            this.txt_RemoveArgs.Name = "txt_RemoveArgs";
            this.txt_RemoveArgs.Size = new System.Drawing.Size(256, 20);
            this.txt_RemoveArgs.TabIndex = 8;
            // 
            // ofd_Insert
            // 
            this.ofd_Insert.FileName = "openFileDialog1";
            this.ofd_Insert.FileOk += new System.ComponentModel.CancelEventHandler(this.ofd_Insert_FileOk);
            // 
            // ofd_Remove
            // 
            this.ofd_Remove.FileName = "openFileDialog1";
            this.ofd_Remove.FileOk += new System.ComponentModel.CancelEventHandler(this.ofd_Remove_FileOk);
            // 
            // cb_ProcessEvents
            // 
            this.cb_ProcessEvents.AutoSize = true;
            this.cb_ProcessEvents.Location = new System.Drawing.Point(15, 423);
            this.cb_ProcessEvents.Name = "cb_ProcessEvents";
            this.cb_ProcessEvents.Size = new System.Drawing.Size(100, 17);
            this.cb_ProcessEvents.TabIndex = 9;
            this.cb_ProcessEvents.Text = "Process Events";
            this.cb_ProcessEvents.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 450);
            this.Controls.Add(this.cb_ProcessEvents);
            this.Controls.Add(this.txt_RemoveArgs);
            this.Controls.Add(this.txt_InsertArgs);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_RemoveBrowse);
            this.Controls.Add(this.btn_InsertBrowse);
            this.Controls.Add(this.txt_RemovePath);
            this.Controls.Add(this.txt_InsertPath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_USBDevices);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_USBDevices;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_InsertPath;
        private System.Windows.Forms.TextBox txt_RemovePath;
        private System.Windows.Forms.Button btn_InsertBrowse;
        private System.Windows.Forms.Button btn_RemoveBrowse;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox txt_InsertArgs;
        private System.Windows.Forms.TextBox txt_RemoveArgs;
        private System.Windows.Forms.OpenFileDialog ofd_Insert;
        private System.Windows.Forms.OpenFileDialog ofd_Remove;
        private System.Windows.Forms.CheckBox cb_ProcessEvents;
    }
}

